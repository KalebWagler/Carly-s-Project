package com.company;

import java.util.Scanner;

public class CarlyEventPrice {


    public static void main() {
        final int RATE_PER_PERSON = 35;
        int numberOfGuest, total;
        boolean isBigEvent;
        String numberOfGuestStr;
        Scanner input = new Scanner(System.in);

        //user inputs how many guests
        System.out.println("Please enter the number of guests attending the event: ");
        numberOfGuestStr = input.nextLine();
        numberOfGuest = Integer.parseInt(numberOfGuestStr);

        try {
            System.out.println("Please enter the number of guests attending the event: ");
            numberOfGuestStr = input.nextLine();
            numberOfGuest = Integer.parseInt(numberOfGuestStr);
        }

        catch (Exception e){
            numberOfGuest = 35;
            System.out.println("Invalid number of guests was entered, and is being defaulted to 35.");
        }

        //compute total
        total = numberOfGuest * RATE_PER_PERSON;

        //checks if big event or not
        if (numberOfGuest >= 50) {
            isBigEvent = true;
        }//end if statement

        else {
            isBigEvent = false;
        }//end else statement

        System.out.println("Number of Guests: " + numberOfGuest +
                "\nPrice per guest: $" + RATE_PER_PERSON +
                "\nTotal price: $" + total +
                "\nIs this this a big event? " + isBigEvent);
    }
}